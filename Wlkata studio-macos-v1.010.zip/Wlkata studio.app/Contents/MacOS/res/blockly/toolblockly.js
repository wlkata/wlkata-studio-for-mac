 window.onload = function() {
     var qvc = new QWebChannel(qt.webChannelTransport, function(channel) {
         window.content = channel.objects.content;
         //receive from qt
         content.sendJsText.connect(function(text) {
                 alert(text);
             })
             //send to QT
         sendcpp = function(text) {
             content.receiveJsText(text);
         }
         content.clearContent.connect(function() {
             Code.discard();
             Code.renderContent();
         })
         content.getBlocklyCount.connect(function() {
             content.recvBlocklyCount(Code.workspace.getAllBlocks(false).length);
         })
         content.getPythonCode.connect(function() {
             content.recvForRunCode(Blockly.Python.workspaceToCode(Code.workspace));
         })
         content.saveBlockly.connect(function() {
             var xml = Blockly.Xml.workspaceToDom(Code.workspace);
             var code = Blockly.Xml.domToText(xml);
             content.recvSaveBlockly(code);
         })
         content.LoadBlocklyXml.connect(function(text) {
             var xmlDom = null;
             try {
                 xmlDom = Blockly.Xml.textToDom(text);
             } catch (e) {
                 content.receiveJsError("Bad Blockly File!");
                 return;
             }
             if (xmlDom) {
                 Code.workspace.clear();
                 Blockly.Xml.domToWorkspace(xmlDom, Code.workspace);
             }
         })
     })
 }

 Blockly.Blocks['Reset'] = {
     init: function() {
         this.appendDummyInput().appendField("Reset");
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Reset'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     return "api.home_simultaneous()\n";
 };

 Blockly.Blocks['SuctionCup'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("SuctionCup")
             .appendField(new Blockly.FieldDropdown([
                 ["On", "On"],
                 ["Off", "Off"]
             ]), "SuctionCup");
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['SuctionCup'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var SuctionCup = block.getFieldValue('SuctionCup');
     if (SuctionCup == "On")
         return "api.suction_cup_on()\n";
     else if (SuctionCup == "Off")
         return "api.suction_cup_off()\n";
 };

 Blockly.Blocks['GCode'] = {
     init: function() {
         this.appendValueInput('VALUE')
             .setCheck('String')
             .appendField('GCode')
             .appendField(new Blockly.FieldTextInput("default"), "Desc");
         this.setInputsInline(true);
         this.setColour(260);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setTooltip('send gcode to machine.');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['GCode'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var cmd = Blockly.Python.valueToCode(block, 'VALUE', Blockly.Python.ORDER_ATOMIC) || '\'\'';
     return 'send_msg(' + cmd + ')\n';
 };

 Blockly.Blocks['Log'] = {
     init: function() {
         this.appendValueInput('VALUE')
             .setCheck('String')
             .appendField('Log');
         this.setInputsInline(true);
         this.setColour(260);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setTooltip('append debug string to script window');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Log'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *";
     var loginfo = Blockly.Python.valueToCode(block, 'VALUE', Blockly.Python.ORDER_ATOMIC) || '\'\'';
     return 'PythonWrap.Log(' + loginfo + ')\n';
 };

 Blockly.Blocks['DOF6'] = {
     init: function() {
         this.appendDummyInput()
             .appendField('DOF6:');
         this.appendValueInput('x')
             .setCheck('Number')
             .appendField('x');
         this.appendValueInput('y')
             .setCheck('Number')
             .appendField('y');
         this.appendValueInput('z')
             .setCheck('Number')
             .appendField('z');
         this.appendValueInput('rx')
             .setCheck('Number')
             .appendField('rx');
         this.appendValueInput('ry')
             .setCheck('Number')
             .appendField('ry');
         this.appendValueInput('rz')
             .setCheck('Number')
             .appendField('rz');
         this.setInputsInline(true);
         this.setColour(260);
         this.setOutput(true, null);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['DOF6'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var x = Blockly.Python.valueToCode(block, 'x', Blockly.Python.ORDER_NONE);
     var y = Blockly.Python.valueToCode(block, 'y', Blockly.Python.ORDER_NONE);
     var z = Blockly.Python.valueToCode(block, 'z', Blockly.Python.ORDER_NONE);
     var rx = Blockly.Python.valueToCode(block, 'rx', Blockly.Python.ORDER_NONE);
     var ry = Blockly.Python.valueToCode(block, 'ry', Blockly.Python.ORDER_NONE);
     var rz = Blockly.Python.valueToCode(block, 'rz', Blockly.Python.ORDER_NONE);
     var code = 'PythonWrap.DOF6(' + x + ',' + y + ',' + z + ',' + rx + ',' + ry + ',' + rz + ')\n';
     return [code, Blockly.Python.ORDER_NONE];
 };


 //2019.8.1
 Blockly.Blocks['Init'] = {
     init: function() {
         this.appendDummyInput().appendField("zero position");
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');

     }
 };
 Blockly.Python['Init'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     return "api.go_to_zero()\n";
 };



 Blockly.Blocks["Pause"] = {
     init: function() {
         this.appendDummyInput().appendField("Pause send");
         this.appendValueInput('t')
             .setCheck('Number');
	     this.appendDummyInput()
		     .appendField("second");
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 }
 Blockly.Python['Pause'] = function(block) {
     Blockly.Python.definitions_.import_time = "import time";
     var t = Blockly.Python.valueToCode(block, 't', Blockly.Python.ORDER_NONE);
     return "time.sleep(" + t + ")\n";
 };
 
  Blockly.Blocks["Delay"] = {
     init: function() {
         this.appendDummyInput()
		     .appendField("delay time");
         this.appendValueInput('t')
             .setCheck('Number');
		this.appendDummyInput()
		     .appendField("second");
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 }
 Blockly.Python['Delay'] = function(block) {
     var t = Blockly.Python.valueToCode(block, 't', Blockly.Python.ORDER_NONE);
     return "api.set_delay_time(" + t + ")\n";
 };


 Blockly.Blocks['MoveTo'] = {
     init: function() {
         this.appendDummyInput()
             .appendField('Move To');
         this.appendDummyInput()
             .appendField("position:");
         this.appendValueInput('x')
             .setCheck('Number')
             .appendField('X');
         this.appendValueInput('y')
             .setCheck('Number')
             .appendField('Y');
         this.appendValueInput('z')
             .setCheck('Number')
             .appendField('Z');
         this.appendDummyInput()
             .appendField("orientation:");
         this.appendValueInput('rx')
             .setCheck('Number')
             .appendField('A');
         this.appendValueInput('ry')
             .setCheck('Number')
             .appendField('B');
         this.appendValueInput('rz')
             .setCheck('Number')
             .appendField('C');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField('F');
         this.setInputsInline(true);

         this.setColour(260);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setTooltip('');
         this.setHelpUrl('');

     }
 };
 Blockly.Python['MoveTo'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var x = Blockly.Python.valueToCode(block, 'x', Blockly.Python.ORDER_NONE);
     var y = Blockly.Python.valueToCode(block, 'y', Blockly.Python.ORDER_NONE);
     var z = Blockly.Python.valueToCode(block, 'z', Blockly.Python.ORDER_NONE);
     var rx = Blockly.Python.valueToCode(block, 'rx', Blockly.Python.ORDER_NONE);
     var ry = Blockly.Python.valueToCode(block, 'ry', Blockly.Python.ORDER_NONE);
     var rz = Blockly.Python.valueToCode(block, 'rz', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var tempValue = x + ' ,' + y + ' ,' + z + ' ,' + rx + ' ,' + ry + ' ,' + rz + ' ,' + f;
     var codeString = "api.go_to_cartesian_lin(" + tempValue + ")\n";
     return codeString;
 }; //ok

 Blockly.Blocks['Speed'] = {
     init: function() {
         this.appendDummyInput()
             .appendField('Speed:');
         this.appendValueInput('speed')
             .setCheck('Number');
         this.setInputsInline(true);
         this.setColour(260);
         //this.setOutput(true, null);
         this.setTooltip('return dof6 inverse result array');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Speed'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var speed = Blockly.Python.valueToCode(block, 'speed', Blockly.Python.ORDER_NONE);
     //var code = 'PythonWrap.DOF6(' + x + ',' + y + ',' + z + ',' + rx + ',' + ry + ',' + rz + ')\n';
     // return [code, Blockly.Python.ORDER_NONE];
 };


 Blockly.Blocks['Move'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("Move")
             .appendField(new Blockly.FieldDropdown([
                 ["forward", "forward"],
                 ["backward", "backward"],
                 ["up", "up"],
                 ["down", "down"],
                 ["right", "right"],
                 ["left", "left"]
             ]), "orientation")
			 .appendField("move");
         this.appendValueInput('d')
             .setCheck('Number');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField('F');
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Move'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var orientation = block.getFieldValue('orientation');
     var d = Blockly.Python.valueToCode(block, 'd', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var codeStringHeard = "api.direction_mobility("
     var codeStringTail = ")\n";
	 var codeString = codeStringHeard+"MoveDirection."+orientation+","+d+","+f+codeStringTail;
     return codeString;
 }; //ok

 Blockly.Blocks['Gripper'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("gripper")
             .appendField(new Blockly.FieldDropdown([
                 ["On", "On"],
                 ["Off", "Off"],
             ]), "gripper");

         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Gripper'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var gripper = block.getFieldValue('gripper');
     if (gripper == "On")
         return "api.suction_cup_on()\n";
     else if (gripper == "Off")
         return "api.suction_cup_off()\n";

 }; //ok

Blockly.Blocks['SliderMoveTo'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("slider move to:");
         this.appendValueInput('d')
             .setCheck('Number')
			 .appendField('D');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField('F');
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
};
Blockly.Python['SliderMoveTo'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var d = Blockly.Python.valueToCode(block, 'd', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     return "api.slider_move_to("+ d+ ", "+ f +")\n";
}; //ok

Blockly.Blocks['ConveyorMoveTo'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("conveyor move:")
			 .appendField(new Blockly.FieldDropdown([
                 ["relative location", "relative"],
                 ["absolute location", "absolute"],
             ]), "location");
         this.appendValueInput('d')
             .setCheck('Number')
			 .appendField('D');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField('F');
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
};
Blockly.Python['ConveyorMoveTo'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var d = Blockly.Python.valueToCode(block, 'd', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var location = block.getFieldValue('location');
     return "api.conveyor_move_to(MoveMode." + location + ", " +d + ", " + f +")\n";
}; //ok


 Blockly.Blocks['TurnTo'] = {
     init: function() {
         this.appendDummyInput()
             .appendField('turn to:');

         this.appendValueInput('x')
             .setCheck('Number')
             .appendField('base');

         this.appendValueInput('y')
             .setCheck('Number')
             .appendField('shoulder');

         this.appendValueInput('z')
             .setCheck('Number')
             .appendField('elbow');

         this.appendValueInput('rx')
             .setCheck('Number')
             .appendField('roll');

         this.appendValueInput('ry')
             .setCheck('Number')
             .appendField('pitch');

         this.appendValueInput('rz')
             .setCheck('Number')
             .appendField('yaw');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField("F");
         this.setInputsInline(true);
         this.setColour(260);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setTooltip('');
         this.setHelpUrl('');

     }
 };
 Blockly.Python['TurnTo'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var x = Blockly.Python.valueToCode(block, 'x', Blockly.Python.ORDER_NONE);
     var y = Blockly.Python.valueToCode(block, 'y', Blockly.Python.ORDER_NONE);
     var z = Blockly.Python.valueToCode(block, 'z', Blockly.Python.ORDER_NONE);
     var rx = Blockly.Python.valueToCode(block, 'rx', Blockly.Python.ORDER_NONE);
     var ry = Blockly.Python.valueToCode(block, 'ry', Blockly.Python.ORDER_NONE);
     var rz = Blockly.Python.valueToCode(block, 'rz', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
	 var tempValue = x + ' ,' + y + ' ,' + z + ' ,' + rx + ' ,' + ry + ' ,' + rz + ' ,' + f;
	 var codeString = "api.go_to_axis(" + tempValue + ")\n";
	 return codeString;
 }; //ok


 Blockly.Blocks['Turn'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("turn")
             .appendField(new Blockly.FieldDropdown([
                 ["base", "base"],
                 ["shoulder", "shoulder"],
                 ["elbow", "elbow"],
                 ["roll", "roll"],
                 ["pitch", "pitch"],
                 ["yaw", "yaw"]
             ]), "turn");
         this.appendDummyInput()
             .appendField(new Blockly.FieldDropdown([
                 ["clockwise", "cw"],
                 ["counterclockwise", "ccw"],
             ]), "rotation");
         this.appendValueInput('d')
             .setCheck('Number')
             .appendField("to");
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField("F");
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };


 Blockly.Python['Turn'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var orientation = block.getFieldValue('turn');
     var d = Blockly.Python.valueToCode(block, 'd', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var rotation = block.getFieldValue('rotation');

     var codeStringHeard = "api.move_to_axis("
     var codeStringTail = ")\n";
     var tempValue = "MirobotJoint."+orientation;
	 var rt = "RevolveDirection."+rotation;
	 var codeString = codeStringHeard+tempValue +", "+ rt+ ", " + d+ ", " +f+codeStringTail;
     return codeString;
 }; //ok
 
Blockly.Blocks['JumpMove'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("Door track movement:")
			 .appendField(new Blockly.FieldDropdown([
                 ["relative_location", "relative"],
                 ["absolute_location", "absolute"],
             ]), "location");
         this.appendValueInput('x')
             .setCheck('Number')
			 .appendField("X");
		this.appendValueInput('y')
             .setCheck('Number')
			 .appendField("Y");
		this.appendValueInput('z')
             .setCheck('Number')
			 .appendField("Z");
         this.appendValueInput('f')
             .setCheck('Number')
			 .appendField("F");
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
};
Blockly.Python['JumpMove'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var x = Blockly.Python.valueToCode(block, 'x', Blockly.Python.ORDER_NONE);
     var y = Blockly.Python.valueToCode(block, 'y', Blockly.Python.ORDER_NONE);
	 var z = Blockly.Python.valueToCode(block, 'z', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var location = block.getFieldValue('location');
     return "api.jump_move(MoveMode." + location + ", " +x + ", " +y+ ", " +z+ ", " + f +")\n";
}; //ok

 
 Blockly.Blocks['ArcMove'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("Arc trajectory movement:")
			 .appendField(new Blockly.FieldDropdown([
                 ["relative_location", "relative"],
                 ["absolute_location", "absolute"],
             ]), "location");
		 this.appendDummyInput()
             .appendField(new Blockly.FieldDropdown([
                 ["clockwise", "cw"],
                 ["counterclockwise", "ccw"],
             ]), "rotation");
         this.appendValueInput('x')
             .setCheck('Number')
			 .appendField("X");
		 this.appendValueInput('y')
             .setCheck('Number')
			 .appendField("Y");
		 this.appendValueInput('z')
             .setCheck('Number')
			 .appendField("Z");
		 this.appendValueInput('r')
             .setCheck('Number')
			 .appendField("R");
         this.appendValueInput('f')
             .setCheck('Number')
			 .appendField("F");
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['ArcMove'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "from mirobot import *\napi=Mirobot()";
     var x = Blockly.Python.valueToCode(block, 'x', Blockly.Python.ORDER_NONE);
     var y = Blockly.Python.valueToCode(block, 'y', Blockly.Python.ORDER_NONE);
	 var z = Blockly.Python.valueToCode(block, 'z', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
	 var r = Blockly.Python.valueToCode(block, 'r', Blockly.Python.ORDER_NONE);
     var location = block.getFieldValue('location');
	 var rotation = block.getFieldValue('rotation');
     return "api.set_arc_move(MoveMode." + location + ", RevolveDirection."+rotation + ", " +x + ", " +y+ ", " +z+ ", " +r +", "+ f +")\n";
 }; //ok

 //  Blockly.Blocks['Test'] = {
 //      init: function() {
 //          this.appendDummyInput().appendField("Test");
 //          this.setPreviousStatement(true, null);
 //          this.setNextStatement(true, null);
 //          this.setColour(170);
 //          this.setTooltip('');
 //          this.setHelpUrl('');
 //      }
 //  };
 //  Blockly.Python['Test'] = function(block) {
 //      Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
 //      return "PythonWrap.GCode('$H')\n";
 //  };